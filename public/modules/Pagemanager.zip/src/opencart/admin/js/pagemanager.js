'use strict';

window.pagemanager = angular.module('pagemanager', []);

window.pagemanager.controller('PageManagerController', function($scope, $http) {

	var _this = this;

	$scope.isSaving = false;
	$scope.activeGroup = false;
	$scope.groups = window.pagemanager_values;
	$scope.newValue = {};

	$scope.addGroup = function(group) {
		var group = group || {
			title: 'New group',
			editMode: false,
			items: []
		};

		$scope.groups.push(group);
		$scope.setActiveGroup(group);

		// Sync data
		$scope.syncData();
	};

	$scope.toggleEditMode = function(item) {
		if (item.editMode && ! _this.validate(item)) {
			item.hasError = true;

			return false;
		};

		item.editMode = !item.editMode;
		item.hasError = false;

		// Sync data
		if ( ! item.editMode) $scope.syncData();
	};

	$scope.setActiveGroup = function(group) {
		$scope.activeGroup = group;
	};

	$scope.addNewValue = function() {
		if ( ! _this.validate($scope.newValue)) {
			$scope.newValue.hasError = true;

			return false;
		};
		
		$scope.activeGroup.items.push($scope.newValue);
		$scope.newValue = {};

		// Sync data
		$scope.syncData();
	};

	$scope.removeItem = function(item) {
		var index = $scope.activeGroup.items.indexOf(item);
		
		$scope.activeGroup.items.splice(index, 1);

		// Sync data
		$scope.syncData();
	};

	$scope.removeGroup = function(group) {
		var index = $scope.groups.indexOf(group);
		
		$scope.groups.splice(index, 1);
		$scope.setActiveGroup(false);
		_this.activateFirstGroup();

		// Sync data
		$scope.syncData();
	};

	$scope.syncData = function(url) {
		var url = url || window.pagemanager_sync_url;

		$scope.isSaving = true;

		$http({
			url: url,
			method: 'post',
			responseType: 'json',
			data: $.param({data: $scope.groups}),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).then(function() {
			$scope.isSaving = false;
		});
	};

	_this.validate = function(item) {
		var all = [];

		// Here we will grap all the keys from all groups except current 
		// in case we are in edit mode
		angular.forEach($scope.groups, function(el) {
			angular.forEach(el.items, function(innerItem) {
				if ( ! angular.equals(innerItem, item)) {
					all.push(innerItem.key);
				};
			});
		});

		// Check if value already exists
		if (all.indexOf(item.key) >= 0) return false;

		// Check for spelling
		return item.key.match(/^[a-zA-Z0-9-_]+$/);
	};

	// Activate first group if it exists
	_this.activateFirstGroup = function() {
		if ( ! $scope.groups.length) return false;

		$scope.setActiveGroup($scope.groups[0]);
	};

	_this.activateFirstGroup();

});

pagemanager.directive('ngEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if(event.which === 13) {
                scope.$apply(function (){
                    scope.$eval(attrs.ngEnter);
                });

                event.preventDefault();
            }
        });
    };
});