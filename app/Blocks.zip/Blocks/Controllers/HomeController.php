<?php namespace Blocks\Controllers;

use Blocks\Models\Module;

class HomeController extends BaseController {

	public function index()
	{
		return 'hello gusts';
	}

}