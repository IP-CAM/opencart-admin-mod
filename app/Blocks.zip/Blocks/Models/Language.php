<?php namespace Blocks\Models;

use Illuminate\Database\Eloquent\Model;

class Language extends Model {}