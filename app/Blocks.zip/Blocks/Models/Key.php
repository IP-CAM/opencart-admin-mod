<?php namespace Blocks\Models;

use Illuminate\Database\Eloquent\Model;

class Key extends Model
{
	
}