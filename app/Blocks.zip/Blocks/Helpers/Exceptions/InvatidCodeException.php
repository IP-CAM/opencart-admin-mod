<?php namespace Blocks\Helpers\Exceptions;

class InvatidCodeException extends \Exception {}