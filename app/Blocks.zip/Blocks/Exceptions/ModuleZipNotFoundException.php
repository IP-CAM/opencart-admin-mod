<?php namespace Blocks\Exceptions;

class ModuleZipNotFoundException extends \Exception {}