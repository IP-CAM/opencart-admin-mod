<?php namespace Blocks\Exceptions;

class InvalidSecretException extends \Exception {}